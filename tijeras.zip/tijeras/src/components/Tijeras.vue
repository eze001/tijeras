<template>
    <div id="Tijeras">
        <button @click="decidir(0)">Piedra</button>
        <button @click="decidir(1)">Papel</button>
        <button @click="decidir(2)">Tijeras</button>
        <p>ganadas: {{ganadas}}</p>
        <p>empatadas: {{empatadas}}</p>
        <p>perdidas: {{perdidas}}</p>
        <div>
            <ol>
                <li v-for="(act,index) in resultado" :key="index">{{act}}, escogiste:{{eleccion[index]}}, escogio la cpu:{{salio[index]}}</li>
            </ol>
        </div>
    </div>
</template>

<script>
export default {
    name:"Tijeras",
    data(){
        return{
            ganadas:0,
            empatadas:0,
            perdidas:0,
            resultado:[],
            eleccion:[],
            salio:[],
            indice:0
        };
    },
    methods:{
        escogerAleatorio(){
            var a=Math.random();
            if(a<=1/3){
                return 0;
            }else if(a<=2/3){
                return 1;
            }else{
                return 2;
            }
        },
        decidir(ele){
            var cpu=this.escogerAleatorio();
            var ind=this.indice;
            if(cpu==0){
                this.salio[ind]="Piedra";
            }else if(cpu==1){
                this.salio[ind]="Papel";
            }else{
                this.salio[ind]="Tijeras";
            }
               if(ele==0){
                this.eleccion[ind]="Piedra";
            }else if(ele==1){
                this.eleccion[ind]="Papel";
            }else{
                this.eleccion[ind]="Tijeras";
            }
            if(ele==cpu){
                this.empatadas++;
                this.resultado[ind]="Empate";
            }else if((ele==0&&cpu==2)||(ele==1&&cpu==0)||(ele==2&&cpu==1)){
                this.ganadas++;
                this.resultado[ind]="Ganaste";
            }else{
                this.perdidas++;
                this.resultado[ind]="Perdiste";
            }
            this.indice++;
        }
    }
}
</script>

