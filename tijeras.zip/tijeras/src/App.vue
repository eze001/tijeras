<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
    <Tijeras />
  </div>
</template>

<script>
import Tijeras from './components/Tijeras.vue'

export default {
  name: 'App',
  components: {
    Tijeras
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
